# Compositional-Rationale-Extraction-Model
Codes and models for the project: Compositional Rationale Extraction Model for Clinical Outcome Prediction

### Dataset
1. To access the MIMIC3 dataset, please go to https://physionet.org/content/mimiciii/1.4/
2. Process data([process_data.ipynb](process_data.ipynb))

### Pre-trained Language Model
The pre-trained language model, ClinicalBERT can be downloaded here: https://github.com/kexinhuang12345/clinicalBERT

### Run
1. model training:
   ```
   python -m rrtl.run_eraser --run-name OUTPUT_FOLDER_NAME --model-type clinicalbert_comp --lr 1e-5 --dataparallel True --batch_size 8 --num_epoch 5 --grad_accumulation_steps 2 --pi 0.2 --beta 0.01 --tau 0.1 --max_length 512 --comp_level
   ```
3. model evaluation:
   ```
   python -m rrtl.analysis.eraser.run_token_level_analysis --dataset_name beer --no_rationale --dataset_split test --eval_mode new_stats --load_path PATH_TO_MODEL
   ```

### Models
The trained models can be downloaded here: [https://drive.google.com/drive/folders/1Cha8ChjGYHa-eUNTEMEBu_39jbSvbxZH?usp=drive_link](https://drive.google.com/drive/folders/1GyQwVGD4mCVG0dsNp_69qn68_blU96jv?usp=drive_link)

### Dependencies
All dependencies are specified in [requirements.txt](requirements.txt)
