from rr.attacks.corenlp.client import CoreNLPClient
from rr.attacks.corenlp.server import CoreNLPServer
from rr.attacks.corenlp.util import *
