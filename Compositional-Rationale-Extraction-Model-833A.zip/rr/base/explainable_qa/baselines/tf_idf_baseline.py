# tokenizer is only white_space
# eval features at sentence level
# bigram bag-of-word vector is constructed for every sentence (incl question) for a given training instance

# How good are non-parametric models that rely on heuristics to obtain rationales? specially when you want
# to show your unsupervised results in a good light

# hard rationale prediction models that are able to explain well waht is happening

# The aim is to show where distantly supervised sentence selector models stack up with heuristic driven techniques; this serves as a baseline that strengthe's the work