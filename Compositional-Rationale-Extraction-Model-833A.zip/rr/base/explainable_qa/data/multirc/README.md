This dataset comes from https://cogcomp.seas.upenn.edu/multirc/ .

Test data comes from Daniel Khashabi (Same subset as SuperGLUE)

Folder `all` contains all answers per question denormalized into individual annotations.
Train / Dev / Test - 27243 / 4848 / 9693 